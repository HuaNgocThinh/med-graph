# BÁO CÁO CHẤT LƯỢNG DỮ LIỆU & ANNOTATION (QUALITY REPORT)
**Dự án MedGraph-VI — Student-Teacher Training Pipeline**

---

## 1. TỔNG QUAN TOÀN BỘ DATASET

Tập dữ liệu huấn luyện cho mô hình Student được tạo lập tự động thông qua Pipeline Teacher (Gemini + Neo4j + Rules Guard + Data Augmentation). Toàn bộ 96 văn bản lâm sàng tổng hợp (`syn_001` đến `syn_096`) được phân bổ đồng bộ theo **tỉ lệ Stratified Split 70% Train / 15% Dev / 15% Test** với các ràng buộc nghiêm ngặt nhằm chống data leakage.

### Phân bổ Sample ID giữa các tập:
- **Train Set (67 sample_ids):** 67 văn bản lâm sàng gốc + 16 câu tổng hợp augmented (cho nhãn hiếm).
- **Dev Set (14 sample_ids):** 14 văn bản lâm sàng gốc.
- **Test Set (15 sample_ids):** 15 văn bản lâm sàng gốc (chứa `syn_095` làm mẫu đánh giá độc lập).
- **Phân tán mẫu phẫu thuật lặp (`syn_005`, `syn_069`, `syn_088`, `syn_092`, `syn_095`):**
  - `syn_005`, `syn_069`, `syn_088` $\rightarrow$ **Train Set**
  - `syn_092` $\rightarrow$ **Dev Set**
  - `syn_095` $\rightarrow$ **Test Set**
- **Cam kết:** Không có `sample_id` nào xuất hiện đồng thời ở 2 tập khác nhau. Dev và Test hoàn toàn KHÔNG chứa dữ liệu tổng hợp (augmented=false).

---

## 2. TỔNG QUAN THỐNG KÊ NER DATASET (CoNLL-2003 FORMAT)

Đã làm sạch 3 entity bị NER gán nhầm label (`men gan`, `Hemoglobin`, `INR`).

### 2.1 Thống kê Token & Tỉ lệ O / Non-O

| Tập Dữ liệu | Số câu (Sentences) | Tổng Token | Số Token O | Tỉ lệ Token O (%) | Số Token Non-O | Tỉ lệ Non-O (%) |
|---|---|---|---|---|---|---|
| **NER Train** | 67 | 3,356 | 2,417 | **72.0%** | 939 | 28.0% |
| **NER Dev** | 14 | 772 | 547 | **70.9%** | 225 | 29.1% |
| **NER Test** | 15 | 746 | 555 | **74.4%** | 191 | 25.6% |
| **TỔNG CỘNG** | **96** | **4,874** | **3,519** | **72.2%** | **1,355** | **27.8%** |

*(Tỉ lệ Token O đạt 72.2%, nằm hoàn hảo trong khoảng mục tiêu 70% – 80%).*

### 2.2 Phân bổ Entity Spans theo Label & Split

| Label Entity | Train Set | Dev Set | Test Set | Tổng Entity Spans | Tỉ lệ (%) |
|---|---|---|---|---|---|
| **SYMPTOM** | 108 | 27 | 27 | **162** | 40.0% |
| **DISEASE** | 89 | 27 | 20 | **136** | 33.6% |
| **DRUG** | 67 | 15 | 18 | **100** | 24.7% |
| **PROCEDURE** | 10 | 2 | 3 | **15** | 3.7% |
| **TỔNG CỘNG** | **274** | **71** | **68** | **413** | **100.0%** |

---

## 3. TỔNG QUAN THỐNG KÊ RE DATASET (BERT FINE-TUNING FORMAT)

Thực hiện Data Augmentation trên 2 nhãn hiếm `CONTRAINDICATED_FOR` (+8 câu) và `CAUSES` (+8 câu), đưa tổng số record từ 299 lên **315 records**. Đã kiểm tra và tinh chỉnh câu augmented CAUSES số 3 chỉ chứa duy nhất 1 tail entity (`vàng da`).

### 3.1 Phân phối Nhãn trước và sau Augmentation

| Tên Nhãn Relation | Trước Aug. | Sau Aug. | Tỉ lệ (%) | Train Set | Dev Set | Test Set |
|---|---|---|---|---|---|---|
| **NONE** | 90 | **90** | 28.6% | 44 | 30 | 16 |
| **HAS_SYMPTOM** | 85 | **85** | 27.0% | 61 | 13 | 11 |
| **PRESCRIBED_FOR** | 65 | **65** | 20.6% | 46 | 8 | 11 |
| **TREATS** | 42 | **42** | 13.3% | 30 | 7 | 5 |
| **PERFORMED_FOR** | 13 | **13** | 4.1% | 8 | 2 | 3 |
| **CONTRAINDICATED_FOR** | 2 | **10** *(+8)* | 3.2% | 10 | 0 | 0 |
| **CAUSES** | 2 | **10** *(+8)* | 3.2% | 10 | 0 | 0 |
| **TỔNG CỘNG** | **299** | **315** | **100.0%** | **209 (66.3%)** | **60 (19.0%)** | **46 (14.6%)** |

- **Imbalance Ratio (Max / Min):** Giảm mạnh từ **45.00** down còn **9.00** (`90 / 10 = 9.00`).
- **Phân bổ Record Augmented:** Toàn bộ 16 record augmented chỉ nằm trong `re_train.json`. `re_dev.json` và `re_test.json` chứa 100% dữ liệu gốc thực tế.

---

## 4. DỰ THƯỜNG & ĐÁNH GIÁ CHẤT LƯỢNG (AGREEMENT RATE & ERROR ANALYSIS)

### 4.1 Agreement Rate với Gold Label (`re_annotation_set.csv`)
- **Số mẫu thử nghiệm độc lập:** 120 quan hệ được chuyên gia gán nhãn thủ công (Gold Standard).
- **Số quan hệ Teacher trùng khớp với Gold:** **114 / 120 mẫu**.
- **Agreement Rate:** **95.00%** (Vượt xa chỉ tiêu yêu cầu $\ge 85\%$).

### 4.2 Top-5 Trường hợp Teacher Khác biệt so với Gold Label

1. `syn_023`: `Trào ngược dạ dày thực quản` $\rightarrow$ `ợ nóng`
   - *Teacher:* `HAS_SYMPTOM` | *Gold:* `TREATS`
   - *Phân tích:* `ợ nóng` là triệu chứng của Trào ngược dạ dày thực quản, việc Gold đánh dấu `TREATS` là nhầm lẫn nhỏ trong file annotation gốc.
2. `syn_031`: `thuốc giãn cơ trơn` $\rightarrow$ `Sỏi thận`
   - *Teacher:* `PRESCRIBED_FOR` | *Gold:* `uncertain`
   - *Phân tích:* Bác sĩ chỉ định thuốc giãn cơ trơn khi bị Sỏi thận để hỗ trợ tống sỏi. Teacher ghi nhận đúng quan hệ chỉ định lâm sàng.
3. `syn_031`: `thuốc giãn cơ trơn` $\rightarrow$ `Đau quặn thận trái`
   - *Teacher:* `TREATS` | *Gold:* `uncertain`
   - *Phân tích:* Thuốc giãn cơ trơn có tác dụng giảm cơn đau quặn thận trái.
4. `syn_038`: `Tai biến mạch máu脑` $\rightarrow$ `Liệt nhẹ nửa người trái`
   - *Teacher:* `HAS_SYMPTOM` | *Gold:* `uncertain`
   - *Phân tích:* Liệt nửa người là biến chứng/dấu hiệu thần kinh trực tiếp của Tai biến mạch máu não.
5. `syn_049`: `Sertraline 50mg` $\rightarrow$ `Hồi hộp`
   - *Teacher:* `TREATS` | *Gold:* `PRESCRIBED_FOR`
   - *Phân tích:* Sertraline điều trị triệu chứng hồi hộp/lo âu (ranh giới giữa TREATS cho triệu chứng và PRESCRIBED_FOR cho hội chứng).

---

## 5. KẾT LUẬN

1. **Chất lượng Annotation:** Đạt **95.00% Agreement Rate**, thể hiện độ tin cậy rất cao của nhãn pseudo-label do Teacher sinh ra.
2. **Cân bằng & Phủ nhãn:** Data Augmentation thành công đưa tỉ lệ mất cân bằng xuống 9.00, bổ sung đầy đủ nhãn hiếm và mở rộng schema cho node/relation `PROCEDURE` / `PERFORMED_FOR`.
3. **Phân chia Không Leakage:** Tất cả các tập Train/Dev/Test cho cả NER và RE đều tuân thủ chặt chẽ nguyên tắc chia tách theo `sample_id`.
4. **Đánh giá Đủ Điều kiện:** **Tập dữ liệu HOÀN TOÀN ĐỦ CHẤT LƯỢNG VÀ SẴN SÀNG để đem đi fine-tune Student NER & Student RE ở Giai đoạn 2.**
